# Privacy Policy

## We Do NOT do this

1. We don't track any user data
2. We don't use Google analytics or similar services

## We Only do this

1. Use socket.io for webrtc handshake

## and that's it.